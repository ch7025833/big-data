import java.lang.*;
import java.io.*;
import java.util.*;
        
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
        
public class WordCount3 {
 public static String[] rightOrder = new String[100];
 public static int[] numbers = new int[100]; 
 public static void sort(Text key,int value){
     if (value > numbers[99]){
        numbers[99] = value;
        rightOrder[99] = key.toString();
        BubbleSort();
     }
 } 
public static void BubbleSort()
{
     int j;
     boolean flag = true;  
     int temp = 0;   
     String tempString;
     while ( flag )
     {
            flag= false;    
            for( j=0;  j < numbers.length -1;  j++ )
            {
                   if ( numbers[ j ] < numbers[j+1] )   
                   {       tempString = rightOrder[j];
                           rightOrder[j] = rightOrder[j+1];
                           rightOrder[j+1] = tempString;
                           temp = numbers[j];
                           numbers[ j ] = numbers[ j+1 ];
                           numbers[ j+1 ] = temp;
                           flag = true;  
                   } 
            } 
      }
}      
 public static class Map extends Mapper<LongWritable, Text, Text, IntWritable> {
    private final static IntWritable one = new IntWritable(1);
    private Text word = new Text();
        
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String line = value.toString();
        StringTokenizer tokenizer = new StringTokenizer(line);
        while (tokenizer.hasMoreTokens()) {
	    String check = tokenizer.nextToken();
            if (check.length()==7){
	       word.set(check);
               context.write(word, one); 
	       }	          
        }
    }
 } 
        
 public static class Reduce extends Reducer<Text, IntWritable, Text, IntWritable> {

    public void reduce(Text key, Iterable<IntWritable> values, Context context) 
      throws IOException, InterruptedException {
        int sum = 0;
        for (IntWritable val : values) {
            sum += val.get();
        }
        sort(key,sum);
        //context.write(key, new IntWritable(sum));
        System.out.println("the context.nextKeyValue()=:"+context.nextKeyValue());
        if (context.nextKeyValue() == false) {
                 for (int i=0;i<numbers.length;i++){
                      Text temp = new Text(rightOrder[i]); 
                      context.write(temp, new IntWritable(numbers[i]));
                 }
        }
    }
 }
        
 public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
        
        Job job = new Job(conf, "wordcount");
    
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(IntWritable.class);
        
    job.setMapperClass(Map.class);
    job.setReducerClass(Reduce.class);
        
    job.setInputFormatClass(TextInputFormat.class);
    job.setOutputFormatClass(TextOutputFormat.class);

    job.setNumReduceTasks(1);
    job.setJarByClass(WordCount3.class);
        
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(args[1]));
        
    job.waitForCompletion(true);
   
 }
        
}
